package com.udacity.catpoint.security.service;

import com.udacity.catpoint.image.service.ImageService;
import com.udacity.catpoint.security.application.StatusListener;
import com.udacity.catpoint.security.data.*;
import org.checkerframework.checker.units.qual.A;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.EnumSource;
import org.junit.jupiter.params.provider.ValueSource;
import org.mockito.ArgumentMatchers;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.awt.image.BufferedImage;
import java.util.HashSet;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class SecurityServiceTest {

    private  SecurityService securityService;
    @Mock
    private StatusListener listener;

    @Mock
    private SecurityRepository securityRepository;

    @Mock
    private ImageService imageService;

    @Mock
    private Sensor sensor;


    @BeforeEach
    void init(){

            securityService = new SecurityService(securityRepository, imageService);

            sensor = new Sensor("detected",SensorType.DOOR);

    }
//
//    @ParameterizedTest
//    @ValueSource(booleans = {true, false})
//    @DisplayName("if alert is activated then any Changes in sensor-state should not influence the alarm-state.")
//    public void ExtraTest(boolean state) {
//            when(securityRepository.getAlarmStatus()).thenReturn(AlarmStatus.ALARM);
//            securityService.changeSensorActivationStatus(sensor, state);
//            verify(securityRepository).setAlarmStatus(any(AlarmStatus.class));
//    }

    // Test - 1
    @Test
    void changeStatusToPending_sysArmed_sensorActivates() {
        try {

            when(securityRepository.getArmingStatus()).thenReturn(ArmingStatus.ARMED_HOME);
            when(securityRepository.getAlarmStatus()).thenReturn(AlarmStatus.NO_ALARM);
            securityService.changeSensorActivationStatus(sensor, true);
            verify(securityRepository).setAlarmStatus(AlarmStatus.PENDING_ALARM);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    //Test 2
    @Test
    public void application_requring_testcase2()
    {
        try
        {
            when(securityRepository.getArmingStatus()).thenReturn(ArmingStatus.ARMED_HOME);
            when(securityRepository.getAlarmStatus()).thenReturn(AlarmStatus.PENDING_ALARM);
            securityService.changeSensorActivationStatus(sensor,true);
            verify(securityRepository).setAlarmStatus(AlarmStatus.ALARM);
        } catch (Exception e) {
           e.printStackTrace();
        }

    }

    //Test case-3
    @Test
    public void application_requring_testcase3()
    {
        try {
            when(securityRepository.getAlarmStatus()).thenReturn(AlarmStatus.PENDING_ALARM);
            securityService.changeSensorActivationStatus(sensor, true);
            securityService.changeSensorActivationStatus(sensor, false);
            verify(securityRepository, times(1)).setAlarmStatus(AlarmStatus.NO_ALARM);
        } catch (Exception e) {
          e.printStackTrace();
        }
    }

    //Test case-4
    @ParameterizedTest
    @ValueSource(booleans ={true,false})
    public void application_requring_testcase4(boolean s)
    {
        try {
            when(securityRepository.getAlarmStatus()).thenReturn(AlarmStatus.ALARM);
            securityService.changeSensorActivationStatus(sensor, s);
            verify(securityRepository, never()).setAlarmStatus(any(AlarmStatus.class));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    //Test case-5

    @Test
    public void application_requring_testcase5()
    {
        try {
            when(securityRepository.getAlarmStatus()).thenReturn(AlarmStatus.PENDING_ALARM);
            securityService.changeSensorActivationStatus(sensor, true);
            verify(securityRepository, times(1)).setAlarmStatus(AlarmStatus.ALARM);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    //Test case-6
    @Test
    public void application_requring_testcase6a()
    {
        try {
            sensor.setActive(false);
            when(securityRepository.getAlarmStatus()).thenReturn(AlarmStatus.ALARM);
            securityService.changeSensorActivationStatus(sensor, false);
            verify(securityRepository, never()).setAlarmStatus(any(AlarmStatus.class));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    @Test
    public void application_requring_testcase6b()
    {
        try {
            sensor.setActive(false);
            when(securityRepository.getAlarmStatus()).thenReturn(AlarmStatus.PENDING_ALARM);
            securityService.changeSensorActivationStatus(sensor, false);
            verify(securityRepository, never()).setAlarmStatus(any(AlarmStatus.class));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    @Test
    public void application_requring_testcase6c()
    {
        try {
            sensor.setActive(false);
            when(securityRepository.getAlarmStatus()).thenReturn(AlarmStatus.NO_ALARM);
            securityService.changeSensorActivationStatus(sensor, false);
            verify(securityRepository, never()).setAlarmStatus(any(AlarmStatus.class));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    //Test case -7
    @Test
    public void application_requring_testcase7()
    {
        try {
            when(securityRepository.getArmingStatus()).thenReturn(ArmingStatus.ARMED_HOME);
            when(imageService.image_Contains_Cat(any(), ArgumentMatchers.anyFloat())).thenReturn(true);
            securityService.processImage(mock((BufferedImage.class)));
            verify(securityRepository).setAlarmStatus(AlarmStatus.ALARM);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    //Test case-8
    @Test
    public void application_requring_testcase8()
    {
        try {
            Set<Sensor> sensors = new HashSet<>();
            sensors.add(new Sensor("1", SensorType.DOOR));
            sensors.add(new Sensor("2", SensorType.DOOR));
            sensors.add(new Sensor("3", SensorType.DOOR));
            when(securityService.getSensors()).thenReturn(sensors);
            when(imageService.image_Contains_Cat(any(), ArgumentMatchers.anyFloat())).thenReturn(false);
            securityService.processImage(mock(BufferedImage.class));
            verify(securityRepository, times(1)).setAlarmStatus(AlarmStatus.NO_ALARM);
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    //Test case-9
    @Test
    public void application_requring_testcase9()
    {
        try {
            securityService.setArmingStatus(ArmingStatus.DISARMED);
            verify(securityRepository).setAlarmStatus(AlarmStatus.NO_ALARM);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    //Test case-10
    @ParameterizedTest
    @EnumSource(value=ArmingStatus.class,names = {"ARMED_AWAY","ARMED_HOME"})
    public void application_requring_testcase10(ArmingStatus status)
    {
        try {
            Set<Sensor> sensors = new HashSet<>();
            sensors.add(new Sensor("1", SensorType.DOOR));
            sensors.add(new Sensor("2", SensorType.DOOR));
            sensors.add(new Sensor("3", SensorType.DOOR));
            when(securityService.getAlarmStatus()).thenReturn(AlarmStatus.PENDING_ALARM);
            when(securityService.getSensors()).thenReturn(sensors);
            securityService.setArmingStatus(status);
            securityService.getSensors().forEach(sensor -> {
                assertFalse(sensor.getActive());
            });
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    //Test case:-11
    @Test
    public void application_requring_testcase11()
    {
        try {
            when(imageService.image_Contains_Cat(any(), anyFloat())).thenReturn(true);
            securityService.processImage(mock(BufferedImage.class));
            securityService.setArmingStatus(ArmingStatus.ARMED_HOME);
            verify(securityRepository, times(1)).setAlarmStatus(AlarmStatus.ALARM);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }


}







