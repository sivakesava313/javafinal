module secuirityservicemodule {
    requires software.amazon.eventstream;
    requires java.rmi;
    requires miglayout;
    requires jdk.crypto.cryptoki;
    requires imageservice;
    requires java.compiler;
    requires java.prefs;
    requires software.amazon.awssdk.awscore;
    requires com.google.gson;
    requires jdk.charsets;
    requires com.google.common;
    requires java.desktop;
    opens com.udacity.catpoint.security.data to com.google.gson;
     }

