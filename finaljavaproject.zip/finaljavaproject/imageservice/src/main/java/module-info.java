module imageservice {
    exports com.udacity.catpoint.image.service to secuirityservice, secuirityservicemodule;
    requires software.amazon.awssdk.auth;
    requires org.slf4j;
    requires software.amazon.awssdk.services.rekognition;
    requires software.amazon.awssdk.regions;
    requires software.amazon.awssdk.metrics;
    requires software.amazon.awssdk.core;
    requires software.amazon.awssdk.utils;
    requires java.desktop;
    requires software.amazon.awssdk.awscore;

}
